(function(){
	/**
	 * String Prototype Extensions
	*/

	Object.assign(String.prototype, {
        title() {
            return this.charAt(0).toUpperCase() + this.slice(1);
        },
    });

})();
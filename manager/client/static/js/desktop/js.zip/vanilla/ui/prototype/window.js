(function(){
	/**
	 * Window Extensions
	*/

    window.width = window.innerWidth;

})();
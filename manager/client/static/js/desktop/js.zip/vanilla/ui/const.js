
export const storage = localStorage;
export var timeout;
import { Image } from '../image.js';

export class BrandEdit extends Image{
	constructor(context){
		super(context);
	}
}
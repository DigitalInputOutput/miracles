import { Image } from '../image.js';

export class CategoryEdit extends Image{
	static block = 'main';

	constructor(context){
		super(context);
	}
}
class Compare{
    constructor(){
        
    }
}